package com.example.safearmlink;

import com.simibubi.create.content.kinetics.mechanicalArm.ArmBlockEntity;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPoint;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPointType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.BlockCapabilityCache;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemHandlerHelper;
import net.minecraft.server.level.ServerLevel;
import org.jetbrains.annotations.Nullable;

/** Create Mechanical Arm target backed by the inventory directly below the plate. */
public final class LinkPlateArmPoint extends ArmInteractionPoint {
    public LinkPlateArmPoint(ArmInteractionPointType type, Level level, BlockPos pos, BlockState state) {
        super(type, level, pos, state);
        if (state.getValue(LinkPlateBlock.OUTPUT))
            cycleMode(); // output mode means the arm takes items from the chest
    }

    @Override
    protected Vec3 getInteractionPositionVector() {
        return Vec3.atLowerCornerOf(pos).add(.5, .08, .5);
    }

    @Override
    protected Direction getInteractionDirection() {
        return Direction.DOWN;
    }

    private BlockPos storagePos() {
        return pos.below();
    }

    @Override
    public boolean isValid() {
        updateCachedState();
        if (!(cachedState.getBlock() instanceof LinkPlateBlock) || level.getBlockEntity(pos.below()) == null)
            return false;
        return level.getCapability(Capabilities.ItemHandler.BLOCK, storagePos(), Direction.UP) != null;
    }

    @Override
    public void updateCachedState() {
        BlockState old = cachedState;
        super.updateCachedState();
        if (old != cachedState)
            cachedAngles = null;
    }

    @Override
    protected @Nullable IItemHandler getHandler(ArmBlockEntity arm) {
        if (level == null || !(level instanceof ServerLevel serverLevel))
            return null;
        BlockPos target = storagePos();
        BlockEntity be = level.getBlockEntity(target);
        if (be == null)
            return null;
        if (cachedHandler == null) {
            cachedHandler = BlockCapabilityCache.create(Capabilities.ItemHandler.BLOCK, serverLevel, target,
                    Direction.UP, () -> !arm.isRemoved(), () -> cachedHandler = null);
        }
        return cachedHandler.getCapability();
    }

    @Override
    public ItemStack insert(ArmBlockEntity arm, ItemStack stack, boolean simulate) {
        // A filtered plate only accepts matching items when the arm is depositing.
        LinkPlateBlockEntity plate = getPlate();
        if (plate == null || !plate.accepts(stack))
            return stack;
        IItemHandler handler = getHandler(arm);
        return handler == null ? stack : ItemHandlerHelper.insertItem(handler, stack, simulate);
    }

    @Override
    public ItemStack extract(ArmBlockEntity arm, int slot, int amount, boolean simulate) {
        // Simulate first so a mismatching stack is never removed from storage.
        LinkPlateBlockEntity plate = getPlate();
        IItemHandler handler = getHandler(arm);
        if (plate == null || handler == null || slot < 0 || slot >= handler.getSlots())
            return ItemStack.EMPTY;
        ItemStack preview = handler.extractItem(slot, amount, true);
        if (preview.isEmpty() || !plate.accepts(preview))
            return ItemStack.EMPTY;
        return simulate ? preview : handler.extractItem(slot, amount, false);
    }

    @Override
    public int getSlotCount(ArmBlockEntity arm) {
        IItemHandler handler = getHandler(arm);
        return handler == null ? 0 : handler.getSlots();
    }

    private @Nullable LinkPlateBlockEntity getPlate() {
        BlockEntity be = level.getBlockEntity(pos);
        return be instanceof LinkPlateBlockEntity plate ? plate : null;
    }

    public static final class Type extends ArmInteractionPointType {
        @Override
        public boolean canCreatePoint(Level level, BlockPos pos, BlockState state) {
            if (!(state.getBlock() instanceof LinkPlateBlock))
                return false;
            return level.getBlockEntity(pos.below()) != null
                    && level.getCapability(Capabilities.ItemHandler.BLOCK, pos.below(), Direction.UP) != null;
        }

        @Override
        public ArmInteractionPoint createPoint(Level level, BlockPos pos, BlockState state) {
            return new LinkPlateArmPoint(this, level, pos, state);
        }
    }
}
