package com.example.safearmlink;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/** A low-profile plate placed directly above a storage block. */
public class LinkPlateBlock extends Block implements EntityBlock {
    public static final BooleanProperty OUTPUT = BooleanProperty.create("output");

    public LinkPlateBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(OUTPUT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(OUTPUT);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new LinkPlateBlockEntity(pos, state);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (level.isClientSide)
            return InteractionResult.SUCCESS;
        LinkPlateBlockEntity be = getEntity(level, pos);
        if (be == null)
            return InteractionResult.PASS;
        if (player.isShiftKeyDown()) {
            be.clearFilter();
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.safearmlink.filter_cleared"), true);
            return InteractionResult.SUCCESS;
        }
        boolean next = !state.getValue(OUTPUT);
        level.setBlock(pos, state.setValue(OUTPUT, next), Block.UPDATE_ALL);
        player.displayClientMessage(net.minecraft.network.chat.Component.translatable(
                next ? "message.safearmlink.output" : "message.safearmlink.input"), true);
        return InteractionResult.SUCCESS;
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                          Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide)
            return InteractionResult.SUCCESS;
        LinkPlateBlockEntity be = getEntity(level, pos);
        if (be == null)
            return InteractionResult.PASS;
        be.setFilter(stack);
        player.displayClientMessage(net.minecraft.network.chat.Component.translatable(
                "message.safearmlink.filter_set", stack.getHoverName()), true);
        return InteractionResult.SUCCESS;
    }

    private static @Nullable LinkPlateBlockEntity getEntity(Level level, BlockPos pos) {
        BlockEntity be = level.getBlockEntity(pos);
        return be instanceof LinkPlateBlockEntity plate ? plate : null;
    }
}
