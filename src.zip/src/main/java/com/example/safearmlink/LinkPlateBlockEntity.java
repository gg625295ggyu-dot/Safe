package com.example.safearmlink;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Stores a single-item whitelist filter for the linked storage. */
public class LinkPlateBlockEntity extends BlockEntity {
    private ItemStack filter = ItemStack.EMPTY;

    public LinkPlateBlockEntity(BlockPos pos, BlockState state) {
        super(SafeArmLink.LINK_PLATE_BE.get(), pos, state);
    }

    public ItemStack getFilter() {
        return filter;
    }

    public boolean accepts(ItemStack stack) {
        return filter.isEmpty() || ItemStack.isSameItemSameComponents(filter, stack);
    }

    public void setFilter(ItemStack stack) {
        filter = stack.isEmpty() ? ItemStack.EMPTY : stack.copyWithCount(1);
        setChanged();
        sync();
    }

    public void clearFilter() {
        filter = ItemStack.EMPTY;
        setChanged();
        sync();
    }

    private void sync() {
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (!filter.isEmpty())
            tag.put("Filter", filter.save(registries));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        filter = tag.contains("Filter") ? ItemStack.parse(registries, tag.getCompound("Filter")).orElse(ItemStack.EMPTY) : ItemStack.EMPTY;
    }
}
