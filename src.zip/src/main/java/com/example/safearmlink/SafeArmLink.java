package com.example.safearmlink;

import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPointType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(SafeArmLink.MOD_ID)
public final class SafeArmLink {
    public static final String MOD_ID = "safearmlink";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<ArmInteractionPointType> ARM_POINT_TYPES = DeferredRegister.create(CreateBuiltInRegistries.ARM_INTERACTION_POINT_TYPE, MOD_ID);

    public static final DeferredHolder<Block, LinkPlateBlock> LINK_PLATE = BLOCKS.register(
            "link_plate", () -> new LinkPlateBlock(BlockBehaviour.Properties.of().strength(1.5F).noOcclusion()));
    public static final DeferredHolder<Item, BlockItem> LINK_PLATE_ITEM = ITEMS.registerSimpleBlockItem("link_plate", LINK_PLATE);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LinkPlateBlockEntity>> LINK_PLATE_BE = BLOCK_ENTITIES.register(
            "link_plate", () -> BlockEntityType.Builder.of(LinkPlateBlockEntity::new, LINK_PLATE.get()).build(null));
    public static final DeferredHolder<ArmInteractionPointType, ArmInteractionPointType> LINK_ARM_POINT = ARM_POINT_TYPES.register(
            "link_plate", LinkPlateArmPoint.Type::new);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.safearmlink"))
                    .icon(() -> new ItemStack(LINK_PLATE_ITEM.get()))
                    .displayItems((parameters, output) -> output.accept(LINK_PLATE_ITEM.get()))
                    .build());

    public SafeArmLink(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        TABS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        ARM_POINT_TYPES.register(modEventBus);
    }
}
